import $ from 'jquery';
import {firstIndex} from './CloneDropdown';

// document.addEventListener('mouseover', function (event) {

// 	if (event.target.matches('.modal-open')) {
// 		// Run your code to open a modal
// 	}

// 	if (event.target.matches('.close')) {
// 		// Run your code to close a modal
// 	}



export function mouseOver(){
  let firstId = document.getElementById('column_first');
  firstId.addEventListener('mouseover', function(e){
    if(e.target.matches('.dropdown__item')){
      let id = e.target.parentNode.parentNode.id;
      let contentHeight = e.target.parentNode.scrollHeight
      let translateVal = 'translateY(' + contentHeight + 'px)';
      let secondContent = id.replace('first', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'none';
      e.target.parentNode.style.height = contentHeight;
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = translateVal;
      };
    };
    if(e.target.matches('.btn__dropdown')){
      let id = e.target.parentNode.id;
      let contentHeight = e.target.nextElementSibling.scrollHeight;
      let translateVal = 'translateY(' + contentHeight + 'px)';
      let secondContent = id.replace('first', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'none';
      e.target.nextElementSibling.style.height = contentHeight;
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = translateVal;
      };
    };
    if(e.target.matches('.dropdown')){
      let id = e.target.id;
      let contentHeight = e.target.children[2].scrollHeight;
      console.log(e.target.children[2]);
      let translateVal = 'translateY(' + contentHeight + 'px)';
      let secondContent = id.replace('first', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'none';
      e.target.children[2].style.height = contentHeight;
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = translateVal;
      };
    };
  });
  firstId.addEventListener('mouseout', function(e){
    if(e.target.matches('.dropdown__item')){
      let id = e.target.parentNode.parentNode.id;
      let secondContent = id.replace('first', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'height 0.5s ease';
      e.target.parentNode.style.height = '0px';
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = 'translateY(0px)';
      };
    };
    if(e.target.matches('.btn__dropdown')){
      let id = e.target.parentNode.id;
      let secondContent = id.replace('first', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'height 0.5s ease';
      e.target.nextElementSibling.style.height = '0px';
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = 'translateY(0px)';
      };
    };
    if(e.target.matches('.dropdown')){
      let id = e.target.id;
      let secondContent = id.replace('first', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'height 0.5s ease';
      e.target.children[2].style.height = '0px';
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = 'translateY(0px)';
      };
    };
  });
  let SecondId = document.getElementById('column_second');
  SecondId.addEventListener('mouseover', function(e){
    if(e.target.matches('.dropdown__item')){
      let id = e.target.parentNode.parentNode.id;
      let contentHeight = e.target.parentNode.scrollHeight
      let translateVal = 'translateY(' + contentHeight + 'px)';
      let firstContent = id.replace('second', 'first');
      document.getElementById(firstContent).getElementsByClassName("dropdown__content")[0].style.transition = 'none';
      e.target.parentNode.style.height = contentHeight;
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = translateVal;
      };
    };
    if(e.target.matches('.btn__dropdown')){
      let id = e.target.parentNode.id;
      let contentHeight = e.target.nextElementSibling.scrollHeight;
      let translateVal = 'translateY(' + contentHeight + 'px)';
      let firstContent = id.replace('second', 'first');
      document.getElementById(firstContent).getElementsByClassName("dropdown__content")[0].style.transition = 'none';
      e.target.nextElementSibling.style.height = contentHeight;
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = translateVal;
      };
    };
  });
  SecondId.addEventListener('mouseout', function(e){
    if(e.target.matches('.dropdown__item')){
      let id = e.target.parentNode.parentNode.id;
      let firstContent = id.replace('second', 'first');
      document.getElementById(firstContent).getElementsByClassName("dropdown__content")[0].style.transition = 'height 0.5s ease';
      e.target.parentNode.style.height = '0px';
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = 'translateY(0px)';
      };
    };
    if(e.target.matches('.btn__dropdown')){
      let id = e.target.parentNode.id;
      let firstContent = id.replace('second', 'first');
      document.getElementById(firstContent).getElementsByClassName("dropdown__content")[0].style.transition = 'height 0.5s ease';
      e.target.nextElementSibling.style.height = '0px';
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = 'translateY(0px)';
      };
    };
  });
  let thirdId = document.getElementById('column_third');
  thirdId.addEventListener('mouseover', function(e){
    if(e.target.matches('.dropdown__item')){
      let id = e.target.parentNode.parentNode.id;
      let contentHeight = e.target.parentNode.scrollHeight
      let translateVal = 'translateY(' + contentHeight + 'px)';
      let secondContent = id.replace('third', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'none';
      e.target.parentNode.style.height = contentHeight;
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = translateVal;
      };
    };
    if(e.target.matches('.btn__dropdown')){
      let id = e.target.parentNode.id;
      let contentHeight = e.target.nextElementSibling.scrollHeight;
      let translateVal = 'translateY(' + contentHeight + 'px)';
      let secondContent = id.replace('third', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'none';
      e.target.nextElementSibling.style.height = contentHeight;
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = translateVal;
      };
    };
  });
  thirdId.addEventListener('mouseout', function(e){
    if(e.target.matches('.dropdown__item')){
      let id = e.target.parentNode.parentNode.id;
      let secondContent = id.replace('third', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'height 0.5s ease';
      e.target.parentNode.style.height = '0px';
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = 'translateY(0px)';
      };
    };
    if(e.target.matches('.btn__dropdown')){
      let id = e.target.parentNode.id;
      let secondContent = id.replace('third', 'second');
      document.getElementById(secondContent).getElementsByClassName("dropdown__content")[0].style.transition = 'height 0.5s ease';
      e.target.nextElementSibling.style.height = '0px';
      let firstSiblings = document.querySelectorAll('#' + id + ' ~ div'), i;
      for(i = 0; i < firstSiblings.length; ++i){
        firstSiblings[i].style.transform = 'translateY(0px)';
      };
    };
  });
};

















  // });
  // $('#dd_third1').mouseover(function(){
  //   let id = $(this).attr('id');
  //   let idProper = '#' + id;
  //   let contentPath = idProper + ' > .dropdown__content';
  //   let contentHeight = $(contentPath).get(0).scrollHeight;
  //   let secondContent = contentPath.replace('third', 'second');
  //   let pushHeight = contentHeight + 1;
  //   let translateVal = 'translateY(' + pushHeight + 'px)';
  //   $(secondContent).css('transition', 'none');
  //   $(contentPath).css("height", contentHeight);
  //   $(this).nextUntil(id).css('transform', translateVal);
  // });
  // $('#dd_third1').mouseout(function(){
  //   let id = $(this).attr('id');
  //   let idProper = '#' + id;
  //   let contentPath = idProper + ' > .dropdown__content';
  //   let secondContent = contentPath.replace('third', 'second');
  //   $(secondContent).css('transition', 'height 0.5s ease');
  //   $(contentPath).css("height", '0px');
  //   $(this).nextUntil(id).css('transform', 'translateY(0px');
  // });
  // $('#dd_second1').mouseover(function(){
  //   let id = $(this).attr('id');
  //   let idProper = '#' + id;
  //   let contentPath = idProper + ' > .dropdown__content';
  //   let contentHeight = $(contentPath).get(0).scrollHeight;
  //   let firstId = id.replace('second', 'first');
  //   let firstThis = '#' + firstId;
  //   let thirdId = id.replace('second', 'third');
  //   let thirdThis = '#' + thirdId;
  //   let pushHeight = contentHeight + 1;
  //   let translateVal = 'translateY(' + pushHeight + 'px)';
  //   let firstContent = contentPath.replace('second', 'first');
  //   let thirdContent = contentPath.replace('second', 'third');
  //   $(firstContent).css('transition', 'none');
  //   $(thirdContent).css('transition', 'none');
  //   $(contentPath).css("height", contentHeight);
  //   $(this).nextUntil(id).css('transform', translateVal);
  //   $(firstThis).nextUntil(firstId).css("transform", translateVal);
  //   $(thirdThis).nextUntil(thirdId).css("transform", translateVal);
  // });
  // $('#dd_second1').mouseout(function(){
  //   let id = $(this).attr('id');
  //   let idProper = '#' + id;
  //   let contentPath = idProper + ' > .dropdown__content';
  //   let firstId = id.replace('second', 'first');
  //   let firstThis = '#' + firstId;
  //   let thirdId = id.replace('second', 'third');
  //   let thirdThis = '#' + thirdId;
  //   let firstContent = contentPath.replace('second', 'first');
  //   let thirdContent = contentPath.replace('second', 'third');
  //   $(firstContent).css('transition', 'height 0.5s ease');
  //   $(thirdContent).css('transition', 'height 0.5s ease');
  //   $(contentPath).css("height", '0px');
  //   $(this).nextUntil(id).css('transform', 'translateY(0px)');
  //   $(firstThis).nextUntil(firstId).css("transform", 'translateY(0px)');
  //   $(thirdThis).nextUntil(thirdId).css("transform", 'translateY(0px)');
  // });

